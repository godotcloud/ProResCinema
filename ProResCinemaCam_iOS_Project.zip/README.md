# ProResCinemaCam — iPhone 13 Pro Max Native ProRes & 10-Bit Cinema Camera

A full-featured professional cinema camera application built with **SwiftUI**, **AVFoundation**, **Metal**, and **CoreImage**, engineered specifically for **iPhone 13 Pro Max** (`iOS 16.0+`).

## Repository Directory Layout

```text
.
├── .github/workflows/ios-build.yml        # GitHub Actions CI/CD workflow (Xcode 15.4 + XcodeGen -> Unsigned IPA)
├── project.yml                            # XcodeGen specification generating ProResCinemaCam.xcodeproj
├── README.md                              # Build & deployment instructions
└── ProResCinemaCam/
    ├── Info.plist                         # Camera, Microphone, Photos & Files permissions + Landscape lock
    ├── Resources/
    │   └── Rec709_Cinema.cube             # Sample 3D LUT file
    └── Sources/
        ├── CameraEngine.swift             # 10-Bit ProRes 422 HQ/422/LT/Proxy + 3-Lens + Manual ISO/Shutter/WB/Focus
        ├── VideoProcessor.swift           # Metal 10-Bit Viewfinder, 3D LUT, Zebras, Focus Peaking, Scopes & Audio VU
        └── ProResCinemaCamUI.swift        # SwiftUI Landscape Cinema Rig HUD & Interactive Controls
```

## Building via GitHub Actions

1. Extract `ProResCinemaCam_iOS_Project.zip` into the root of your GitHub repository and push to `main` or `master`.
2. The workflow in `.github/workflows/ios-build.yml` runs automatically on `macos-14` with Xcode 15.4:
   - Generates `ProResCinemaCam.xcodeproj` from `project.yml` using `xcodegen`.
   - Verifies compilation against the iOS Simulator SDK.
   - Builds a Release `arm64` iOS app bundle and uploads `ProResCinemaCam-Unsigned.ipa` as a workflow artifact ready for sideloading (AltStore / Sideloadly / TrollStore) or enterprise re-signing.
