import SwiftUI
import AVFoundation
import MetalKit
import UniformTypeIdentifiers

// MARK: - App Entry Point
@main
public struct ProResCinemaCamApp: App {
    @StateObject private var cameraEngine = CameraEngine()

    public init() {}

    public var body: some Scene {
        WindowGroup {
            CinemaMainView(engine: cameraEngine)
                .preferredColorScheme(.dark)
                .statusBarHidden(true)
                .onAppear {
                    cameraEngine.requestPermissionsAndSetup()
                }
        }
    }
}

// MARK: - Real-Time Metal 10-Bit Viewfinder (MTKView)
public struct MetalVideoPreviewView: UIViewRepresentable {
    @ObservedObject var processor: VideoProcessor

    public func makeCoordinator() -> Coordinator {
        Coordinator(processor: processor)
    }

    public func makeUIView(context: Context) -> MTKView {
        let mtkView = MTKView(frame: .zero, device: processor.metalDevice)
        mtkView.framebufferOnly = false
        mtkView.colorPixelFormat = .bgr10a2Unorm // 10-bit per channel Extended Dynamic Range surface
        mtkView.clearColor = MTLClearColor(red: 0.03, green: 0.03, blue: 0.03, alpha: 1.0)
        mtkView.contentMode = .scaleAspectFit
        mtkView.isPaused = false
        mtkView.enableSetNeedsDisplay = false
        mtkView.preferredFramesPerSecond = 60
        mtkView.delegate = context.coordinator
        return mtkView
    }

    public func updateUIView(_ uiView: MTKView, context: Context) {}

    public final class Coordinator: NSObject, MTKViewDelegate {
        let processor: VideoProcessor
        let colorSpace = CGColorSpace(name: CGColorSpace.displayP3) ?? CGColorSpaceCreateDeviceRGB()

        init(processor: VideoProcessor) {
            self.processor = processor
        }

        public func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {}

        public func draw(in view: MTKView) {
            guard let drawable = view.currentDrawable,
                  let commandBuffer = processor.commandQueue?.makeCommandBuffer(),
                  let image = processor.latestProcessedImage else { return }

            let dSize = view.drawableSize
            guard dSize.width > 0 && dSize.height > 0 else { return }

            let scaleX = dSize.width / image.extent.width
            let scaleY = dSize.height / image.extent.height
            let scale = min(scaleX, scaleY)

            let scaledWidth = image.extent.width * scale
            let scaledHeight = image.extent.height * scale
            let offsetX = (dSize.width - scaledWidth) * 0.5
            let offsetY = (dSize.height - scaledHeight) * 0.5

            let transformed = image
                .transformed(by: CGAffineTransform(scaleX: scale, y: scale))
                .transformed(by: CGAffineTransform(translationX: offsetX, y: offsetY))

            processor.ciContext.render(
                transformed,
                to: drawable.texture,
                commandBuffer: commandBuffer,
                bounds: CGRect(origin: .zero, size: dSize),
                colorSpace: colorSpace
            )

            commandBuffer.present(drawable)
            commandBuffer.commit()
        }
    }
}

// MARK: - Main Cinema Rig HUD View
public struct CinemaMainView: View {
    @ObservedObject var engine: CameraEngine
    @ObservedObject var processor: VideoProcessor

    @State private var activeControlTab: ManualTab = .exposure
    @State private var isShowingFormatSheet = false
    @State private var isShowingLUTImporter = false

    public enum ManualTab: String, CaseIterable, Identifiable {
        case exposure = "EXPOSURE"
        case wb       = "WB / TINT"
        case focus    = "FOCUS"
        case monitor  = "ASSIST / LUT"

        public var id: String { rawValue }
    }

    public init(engine: CameraEngine) {
        self.engine = engine
        self.processor = engine.videoProcessor
    }

    public var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            // 1. Live 10-Bit Metal Viewfinder + Framing Guides
            ZStack {
                MetalVideoPreviewView(processor: processor)
                    .ignoresSafeArea()

                FramingGuidesOverlay(
                    showGrid: processor.config.showGridOverlay,
                    aspectGuide: processor.config.aspectRatioGuide,
                    isRecording: engine.isRecording
                )
            }

            // 2. Cinema HUD Overlay
            VStack(spacing: 0) {
                // Top Telemetry & Format Bar
                TopTelemetryBar(
                    engine: engine,
                    processor: processor,
                    onTapFormat: { isShowingFormatSheet = true }
                )

                Spacer()

                // Middle Row: Left Scopes (Histogram + Waveform + Audio VU) & Right Lens / Shutter Controls
                HStack(alignment: .bottom, spacing: 14) {
                    ScopesAndAudioCluster(
                        processor: processor,
                        scopeMetrics: processor.scopeMetrics
                    )

                    Spacer()

                    // Triple Lens Switcher (13mm / 26mm / 77mm)
                    LensSelectorPill(
                        selectedLens: engine.selectedLens,
                        isRecording: engine.isRecording,
                        onSelectLens: { engine.switchLens(to: $0) }
                    )

                    // Big Cinema Record Trigger Button
                    RecordTriggerButton(
                        isRecording: engine.isRecording,
                        codecName: engine.selectedCodec.rawValue,
                        onToggle: { engine.toggleRecording() }
                    )
                }
                .padding(.horizontal, 16)
                .padding(.bottom, 8)

                // Bottom Manual Control Deck (ISO / Shutter Angle / WB Kelvin / Focus / LUT & Zebras)
                BottomManualDeck(
                    engine: engine,
                    processor: processor,
                    activeTab: $activeControlTab,
                    onImportLUT: { isShowingLUTImporter = true }
                )
            }
        }
        .sheet(isPresented: $isShowingFormatSheet) {
            CodecAndPipelineSheet(engine: engine)
        }
        .fileImporter(
            isPresented: $isShowingLUTImporter,
            allowedContentTypes: [UTType(filenameExtension: "cube") ?? .data],
            allowsMultipleSelection: false
        ) { result in
            if case .success(let urls) = result, let url = urls.first {
                let accessed = url.startAccessingSecurityScopedResource()
                defer { if accessed { url.stopAccessingSecurityScopedResource() } }
                do {
                    try processor.loadCubeLUT(from: url)
                    engine.statusBannerMessage = "Loaded 3D LUT: \(url.lastPathComponent)"
                } catch {
                    engine.statusBannerMessage = "LUT load failed: \(error.localizedDescription)"
                }
            }
        }
    }
}

// MARK: - Top Cinema Telemetry Bar
struct TopTelemetryBar: View {
    @ObservedObject var engine: CameraEngine
    @ObservedObject var processor: VideoProcessor
    var onTapFormat: () -> Void

    var body: some View {
        HStack(spacing: 10) {
            // REC Indicator + SMPTE Timecode
            HStack(spacing: 6) {
                Circle()
                    .fill(engine.isRecording ? Color.red : Color.gray.opacity(0.5))
                    .frame(width: 10, height: 10)
                Text(engine.timecodeString)
                    .font(.system(size: 15, weight: .bold, design: .monospaced))
                    .foregroundColor(engine.isRecording ? .red : .white)
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 5)
            .background(Color.black.opacity(0.75))
            .cornerRadius(6)

            // Codec / Resolution / Color Pipeline Button
            Button(action: onTapFormat) {
                HStack(spacing: 6) {
                    Text(engine.selectedCodec.rawValue)
                        .font(.system(size: 12, weight: .heavy, design: .monospaced))
                        .foregroundColor(.black)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(Color.yellow)
                        .cornerRadius(4)

                    Text("\(engine.selectedResolution.rawValue) @ \(engine.selectedFrameRate.rawValue)fps")
                        .font(.system(size: 12, weight: .semibold, design: .monospaced))
                        .foregroundColor(.white)

                    Text(engine.selectedColorPipeline.rawValue)
                        .font(.system(size: 11, weight: .medium, design: .monospaced))
                        .foregroundColor(.cyan)
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 5)
                .background(Color.white.opacity(0.12))
                .cornerRadius(6)
            }
            .disabled(engine.isRecording)

            Spacer()

            // Active Monitoring Badges (LUT / Zebra / Peaking)
            if processor.config.isLUTPreviewEnabled {
                StatusBadge(label: "LUT: \(processor.config.activeLUTName)", color: .mint)
            }
            if processor.config.isZebraEnabled {
                StatusBadge(label: "ZEBRA \(Int(processor.config.zebraThreshold * 100))%", color: .orange)
            }
            if processor.config.isFocusPeakingEnabled {
                StatusBadge(label: "PEAK", color: .green)
            }

            // Storage, Thermal & Battery Readout
            HStack(spacing: 10) {
                Label(
                    String(format: "%.0fGB (%dm)", engine.availableStorageGB, engine.estimatedRemainingMinutes),
                    systemImage: "internaldrive"
                )
                .font(.system(size: 11, weight: .semibold, design: .monospaced))
                .foregroundColor(.white)

                Text(engine.thermalStateDescription)
                    .font(.system(size: 11, weight: .bold, design: .monospaced))
                    .foregroundColor(engine.thermalStateDescription == "Nominal" ? .green : .orange)

                Label("\(engine.batteryLevelPercent)%", systemImage: "battery.100")
                    .font(.system(size: 11, weight: .semibold, design: .monospaced))
                    .foregroundColor(.white)
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 5)
            .background(Color.black.opacity(0.75))
            .cornerRadius(6)
        }
        .padding(.horizontal, 16)
        .padding(.top, 8)
    }
}

struct StatusBadge: View {
    let label: String
    let color: Color

    var body: some View {
        Text(label)
            .font(.system(size: 10, weight: .bold, design: .monospaced))
            .foregroundColor(.black)
            .padding(.horizontal, 6)
            .padding(.vertical, 3)
            .background(color)
            .cornerRadius(4)
    }
}

// MARK: - Framing Guides & Aspect Ratio Mask Overlay
struct FramingGuidesOverlay: View {
    let showGrid: Bool
    let aspectGuide: MonitoringConfig.AspectGuide
    let isRecording: Bool

    var body: some View {
        GeometryReader { geo in
            ZStack {
                // Rule-of-Thirds & Center Crosshair
                if showGrid {
                    Path { path in
                        let w = geo.size.width
                        let h = geo.size.height
                        path.move(to: CGPoint(x: w / 3, y: 0))
                        path.addLine(to: CGPoint(x: w / 3, y: h))
                        path.move(to: CGPoint(x: 2 * w / 3, y: 0))
                        path.addLine(to: CGPoint(x: 2 * w / 3, y: h))
                        path.move(to: CGPoint(x: 0, y: h / 3))
                        path.addLine(to: CGPoint(x: w, y: h / 3))
                        path.move(to: CGPoint(x: 0, y: 2 * h / 3))
                        path.addLine(to: CGPoint(x: w, y: 2 * h / 3))
                    }
                    .stroke(Color.white.opacity(0.22), lineWidth: 0.8)
                }

                // Cinema Aspect Ratio Guide Frame
                if aspectGuide != .none {
                    let targetRatio: CGFloat = {
                        switch aspectGuide {
                        case .cinema239:   return 2.39
                        case .dci185:      return 1.85
                        case .vertical916: return 9.0 / 16.0
                        case .none:        return 16.0 / 9.0
                        }
                    }()
                    let boxW = min(geo.size.width, geo.size.height * targetRatio)
                    let boxH = min(geo.size.height, geo.size.width / targetRatio)
                    Rectangle()
                        .stroke(Color.yellow.opacity(0.65), lineWidth: 1.2)
                        .frame(width: boxW, height: boxH)
                }

                // Red Tally Border When Recording ProRes
                if isRecording {
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(Color.red, lineWidth: 3)
                        .ignoresSafeArea()
                }
            }
        }
        .allowsHitTesting(false)
    }
}

// MARK: - Live RGB Histogram, Luma Waveform & Stereo Audio VU Cluster
struct ScopesAndAudioCluster: View {
    @ObservedObject var processor: VideoProcessor
    let scopeMetrics: ScopeMetrics

    var body: some View {
        HStack(alignment: .bottom, spacing: 8) {
            if processor.config.showHistogram {
                RGBHistogramScopeView(
                    red: scopeMetrics.redHistogram,
                    green: scopeMetrics.greenHistogram,
                    blue: scopeMetrics.blueHistogram
                )
                .frame(width: 120, height: 64)
            }

            if processor.config.showWaveform {
                LumaWaveformScopeView(columns: scopeMetrics.waveformColumns)
                    .frame(width: 120, height: 64)
            }

            StereoAudioMeterView(
                leftDB: scopeMetrics.leftAudioDBFS,
                rightDB: scopeMetrics.rightAudioDBFS
            )
            .frame(width: 44, height: 64)
        }
    }
}

struct RGBHistogramScopeView: View {
    let red: [Float]
    let green: [Float]
    let blue: [Float]

    var body: some View {
        ZStack(alignment: .topLeading) {
            RoundedRectangle(cornerRadius: 6)
                .fill(Color.black.opacity(0.72))

            Canvas { context, size in
                drawChannel(bins: red, color: .red.opacity(0.65), in: &context, size: size)
                drawChannel(bins: green, color: .green.opacity(0.65), in: &context, size: size)
                drawChannel(bins: blue, color: .blue.opacity(0.65), in: &context, size: size)
            }
            .padding(4)

            Text("RGB HIST")
                .font(.system(size: 8, weight: .bold, design: .monospaced))
                .foregroundColor(.white.opacity(0.7))
                .padding(4)
        }
    }

    private func drawChannel(bins: [Float], color: Color, in context: inout GraphicsContext, size: CGSize) {
        guard bins.count > 1 else { return }
        var path = Path()
        path.move(to: CGPoint(x: 0, y: size.height))
        for (i, val) in bins.enumerated() {
            let x = CGFloat(i) / CGFloat(bins.count - 1) * size.width
            let y = size.height - CGFloat(min(1.0, max(0.0, val))) * size.height
            path.addLine(to: CGPoint(x: x, y: y))
        }
        path.addLine(to: CGPoint(x: size.width, y: size.height))
        path.closeSubpath()
        context.fill(path, with: .color(color))
    }
}

struct LumaWaveformScopeView: View {
    let columns: [(min: Float, avg: Float, max: Float)]

    var body: some View {
        ZStack(alignment: .topLeading) {
            RoundedRectangle(cornerRadius: 6)
                .fill(Color.black.opacity(0.72))

            Canvas { context, size in
                guard !columns.isEmpty else { return }
                for (i, col) in columns.enumerated() {
                    let x = CGFloat(i) / CGFloat(max(1, columns.count - 1)) * size.width
                    let yMax = size.height - CGFloat(col.max) * size.height
                    let yMin = size.height - CGFloat(col.min) * size.height
                    var line = Path()
                    line.move(to: CGPoint(x: x, y: yMax))
                    line.addLine(to: CGPoint(x: x, y: yMin))
                    context.stroke(line, with: .color(.green.opacity(0.75)), lineWidth: 1.8)
                }
            }
            .padding(4)

            Text("LUMA IRE")
                .font(.system(size: 8, weight: .bold, design: .monospaced))
                .foregroundColor(.green.opacity(0.85))
                .padding(4)
        }
    }
}

struct StereoAudioMeterView: View {
    let leftDB: Float
    let rightDB: Float

    private func normalized(_ db: Float) -> CGFloat {
        CGFloat(max(0.0, min(1.0, (db + 60.0) / 60.0)))
    }

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 6)
                .fill(Color.black.opacity(0.72))

            HStack(spacing: 6) {
                channelBar(label: "L", level: normalized(leftDB))
                channelBar(label: "R", level: normalized(rightDB))
            }
            .padding(.horizontal, 6)
            .padding(.vertical, 4)
        }
    }

    private func channelBar(label: String, level: CGFloat) -> some View {
        VStack(spacing: 2) {
            GeometryReader { geo in
                ZStack(alignment: .bottom) {
                    RoundedRectangle(cornerRadius: 2)
                        .fill(Color.white.opacity(0.15))
                    RoundedRectangle(cornerRadius: 2)
                        .fill(
                            LinearGradient(
                                colors: [.green, .yellow, .red],
                                startPoint: .bottom,
                                endPoint: .top
                            )
                        )
                        .frame(height: geo.size.height * level)
                }
            }
            Text(label)
                .font(.system(size: 8, weight: .bold, design: .monospaced))
                .foregroundColor(.white.opacity(0.8))
        }
    }
}

// MARK: - Triple Lens Switcher (13mm / 26mm / 77mm)
struct LensSelectorPill: View {
    let selectedLens: CinemaLens
    let isRecording: Bool
    let onSelectLens: (CinemaLens) -> Void

    var body: some View {
        HStack(spacing: 6) {
            ForEach(CinemaLens.allCases) { lens in
                Button(action: { onSelectLens(lens) }) {
                    Text(lens.rawValue)
                        .font(.system(size: 12, weight: .bold, design: .monospaced))
                        .foregroundColor(selectedLens == lens ? .black : .white)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 7)
                        .background(selectedLens == lens ? Color.yellow : Color.white.opacity(0.15))
                        .clipShape(Capsule())
                }
                .disabled(isRecording)
            }
        }
        .padding(5)
        .background(Color.black.opacity(0.75))
        .clipShape(Capsule())
    }
}

// MARK: - Cinema Record Trigger Button
struct RecordTriggerButton: View {
    let isRecording: Bool
    let codecName: String
    let onToggle: () -> Void

    var body: some View {
        Button(action: onToggle) {
            ZStack {
                Circle()
                    .stroke(Color.white, lineWidth: 3)
                    .frame(width: 64, height: 64)

                RoundedRectangle(cornerRadius: isRecording ? 8 : 28)
                    .fill(Color.red)
                    .frame(width: isRecording ? 28 : 50, height: isRecording ? 28 : 50)
                    .animation(.spring(response: 0.25, dampingFraction: 0.7), value: isRecording)
            }
        }
    }
}

// MARK: - Bottom Manual Cinema Control Deck
struct BottomManualDeck: View {
    @ObservedObject var engine: CameraEngine
    @ObservedObject var processor: VideoProcessor
    @Binding var activeTab: CinemaMainView.ManualTab
    var onImportLUT: () -> Void

    var body: some View {
        VStack(spacing: 6) {
            // Mode Tabs + Quick Readout
            HStack(spacing: 8) {
                ForEach(CinemaMainView.ManualTab.allCases) { tab in
                    Button(action: { activeTab = tab }) {
                        Text(tab.rawValue)
                            .font(.system(size: 11, weight: .bold, design: .monospaced))
                            .foregroundColor(activeTab == tab ? .yellow : .white.opacity(0.7))
                            .padding(.horizontal, 10)
                            .padding(.vertical, 4)
                            .background(activeTab == tab ? Color.white.opacity(0.16) : Color.clear)
                            .cornerRadius(5)
                    }
                }

                Spacer()

                Text(engine.statusBannerMessage)
                    .font(.system(size: 10, weight: .medium, design: .monospaced))
                    .foregroundColor(.white.opacity(0.75))
                    .lineLimit(1)
            }

            // Active Parameter Sliders
            Group {
                switch activeTab {
                case .exposure:
                    HStack(spacing: 16) {
                        Toggle("MANUAL EXP", isOn: $engine.isManualExposure)
                            .labelsHidden()
                            .tint(.yellow)
                            .onChange(of: engine.isManualExposure) { _ in engine.applyExposureSettings() }

                        VStack(alignment: .leading, spacing: 2) {
                            Text("ISO \(Int(engine.currentISO))")
                                .font(.system(size: 11, weight: .bold, design: .monospaced))
                                .foregroundColor(.yellow)
                            Slider(value: $engine.currentISO, in: engine.minISO...engine.maxISO)
                                .tint(.yellow)
                                .disabled(!engine.isManualExposure)
                                .onChange(of: engine.currentISO) { _ in engine.applyExposureSettings() }
                        }

                        VStack(alignment: .leading, spacing: 2) {
                            let invShutter = Int(round(1.0 / max(0.0001, engine.currentShutterSeconds)))
                            Text("SHUTTER \(Int(engine.shutterAngle))° (1/\(invShutter)s)")
                                .font(.system(size: 11, weight: .bold, design: .monospaced))
                                .foregroundColor(.cyan)
                            Slider(value: $engine.shutterAngle, in: 45...360, step: 15)
                                .tint(.cyan)
                                .disabled(!engine.isManualExposure)
                                .onChange(of: engine.shutterAngle) { _ in engine.applyExposureSettings() }
                        }
                    }

                case .wb:
                    HStack(spacing: 16) {
                        Toggle("MANUAL WB", isOn: $engine.isManualWhiteBalance)
                            .labelsHidden()
                            .tint(.yellow)
                            .onChange(of: engine.isManualWhiteBalance) { _ in engine.applyWhiteBalanceSettings() }

                        VStack(alignment: .leading, spacing: 2) {
                            Text("TEMP \(Int(engine.whiteBalanceKelvin))K")
                                .font(.system(size: 11, weight: .bold, design: .monospaced))
                                .foregroundColor(.orange)
                            Slider(value: $engine.whiteBalanceKelvin, in: 2500...10000, step: 50)
                                .tint(.orange)
                                .disabled(!engine.isManualWhiteBalance)
                                .onChange(of: engine.whiteBalanceKelvin) { _ in engine.applyWhiteBalanceSettings() }
                        }

                        VStack(alignment: .leading, spacing: 2) {
                            Text("TINT \(Int(engine.whiteBalanceTint))")
                                .font(.system(size: 11, weight: .bold, design: .monospaced))
                                .foregroundColor(.green)
                            Slider(value: $engine.whiteBalanceTint, in: -150...150, step: 1)
                                .tint(.green)
                                .disabled(!engine.isManualWhiteBalance)
                                .onChange(of: engine.whiteBalanceTint) { _ in engine.applyWhiteBalanceSettings() }
                        }
                    }

                case .focus:
                    HStack(spacing: 16) {
                        Button(action: {
                            engine.isManualFocus.toggle()
                            engine.applyFocusSettings()
                        }) {
                            Text(engine.isManualFocus ? "MF LOCKED" : "AF CONTINUOUS")
                                .font(.system(size: 11, weight: .bold, design: .monospaced))
                                .foregroundColor(.black)
                                .padding(.horizontal, 10)
                                .padding(.vertical, 6)
                                .background(engine.isManualFocus ? Color.yellow : Color.green)
                                .cornerRadius(6)
                        }

                        VStack(alignment: .leading, spacing: 2) {
                            Text(String(format: "FOCUS PULL POSITION: %.2f (0.00 Macro → 1.00 Infinity)", engine.lensPosition))
                                .font(.system(size: 11, weight: .bold, design: .monospaced))
                                .foregroundColor(.white)
                            Slider(value: $engine.lensPosition, in: 0.0...1.0)
                                .tint(.yellow)
                                .disabled(!engine.isManualFocus)
                                .onChange(of: engine.lensPosition) { _ in engine.applyFocusSettings() }
                        }
                    }

                case .monitor:
                    HStack(spacing: 10) {
                        Toggle("ZEBRA", isOn: $processor.config.isZebraEnabled)
                            .font(.system(size: 11, weight: .bold, design: .monospaced))
                            .tint(.orange)

                        Toggle("PEAKING", isOn: $processor.config.isFocusPeakingEnabled)
                            .font(.system(size: 11, weight: .bold, design: .monospaced))
                            .tint(.green)

                        Toggle("3D LUT", isOn: $processor.config.isLUTPreviewEnabled)
                            .font(.system(size: 11, weight: .bold, design: .monospaced))
                            .tint(.mint)

                        Button(action: onImportLUT) {
                            Label("Import .cube", systemImage: "square.and.arrow.down")
                                .font(.system(size: 11, weight: .bold, design: .monospaced))
                                .padding(.horizontal, 8)
                                .padding(.vertical, 5)
                                .background(Color.white.opacity(0.18))
                                .cornerRadius(5)
                        }

                        Picker("Guide", selection: $processor.config.aspectRatioGuide) {
                            ForEach(MonitoringConfig.AspectGuide.allCases) { guide in
                                Text(guide.rawValue).tag(guide)
                            }
                        }
                        .pickerStyle(.menu)
                    }
                }
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
        .background(Color.black.opacity(0.84))
    }
}

// MARK: - Codec, Resolution & 10-Bit Pipeline Configuration Sheet
struct CodecAndPipelineSheet: View {
    @ObservedObject var engine: CameraEngine
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            Form {
                Section("Apple ProRes & 10-Bit Codec") {
                    Picker("Codec", selection: $engine.selectedCodec) {
                        ForEach(CinemaCodec.allCases) { codec in
                            Text(codec.rawValue).tag(codec)
                        }
                    }
                    .pickerStyle(.inline)
                }

                Section("Resolution & Frame Rate") {
                    Picker("Resolution", selection: $engine.selectedResolution) {
                        ForEach(CinemaResolution.allCases) { res in
                            Text(res.rawValue).tag(res)
                        }
                    }
                    Picker("Frame Rate", selection: $engine.selectedFrameRate) {
                        ForEach(CinemaFrameRate.allCases) { fps in
                            Text("\(fps.rawValue) fps").tag(fps)
                        }
                    }
                }

                Section("10-Bit Color Space & Transfer Function") {
                    Picker("Color Pipeline", selection: $engine.selectedColorPipeline) {
                        ForEach(CinemaColorPipeline.allCases) { pipe in
                            Text(pipe.rawValue).tag(pipe)
                        }
                    }
                }
            }
            .navigationTitle("ProRes & 10-Bit Pipeline")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Apply") {
                        engine.applyActiveFormatAndColorPipeline()
                        dismiss()
                    }
                }
            }
        }
    }
}
