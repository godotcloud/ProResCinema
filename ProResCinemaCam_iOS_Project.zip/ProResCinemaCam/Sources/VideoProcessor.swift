import Foundation
import CoreImage
import CoreImage.CIFilterBuiltins
import CoreMedia
import CoreVideo
import Metal
import MetalKit
import Accelerate
import AVFoundation
import Combine

// MARK: - Monitoring Tool Configuration
public struct MonitoringConfig {
    public var isZebraEnabled: Bool = false
    /// IRE threshold for Zebra Stripes (0.70 = 70% skin tone, 0.95 = highlight clipping)
    public var zebraThreshold: Float = 0.90

    public var isFocusPeakingEnabled: Bool = false
    /// Edge gradient threshold for Focus Peaking overlay
    public var focusPeakingThreshold: Float = 0.28

    public var isLUTPreviewEnabled: Bool = false
    public var activeLUTName: String = "HLG → Rec.709 Cinema"

    public var showHistogram: Bool = true
    public var showWaveform: Bool = true
    public var showGridOverlay: Bool = true
    public var aspectRatioGuide: AspectGuide = .none

    public enum AspectGuide: String, CaseIterable, Identifiable {
        case none        = "Off"
        case cinema239   = "2.39:1 Anamorphic"
        case dci185      = "1.85:1 Flat"
        case vertical916 = "9:16 Social"

        public var id: String { rawValue }
    }
}

// MARK: - Real-Time Scope & Audio Telemetry Data
public struct ScopeMetrics {
    public var redHistogram: [Float] = Array(repeating: 0, count: 64)
    public var greenHistogram: [Float] = Array(repeating: 0, count: 64)
    public var blueHistogram: [Float] = Array(repeating: 0, count: 64)
    /// 48 columns of normalized luma values (min, average, max) for real-time Luma Waveform
    public var waveformColumns: [(min: Float, avg: Float, max: Float)] = Array(repeating: (0, 0, 0), count: 48)
    public var leftAudioDBFS: Float = -60.0
    public var rightAudioDBFS: Float = -60.0
    public var peakAudioDBFS: Float = -60.0
}

// MARK: - VideoProcessor: 10-Bit Metal Renderer + 3D LUT + Zebras + Focus Peaking + Scopes
public final class VideoProcessor: ObservableObject {
    public let metalDevice: MTLDevice?
    public let commandQueue: MTLCommandQueue?
    public let ciContext: CIContext

    @Published public var config = MonitoringConfig()
    @Published public var scopeMetrics = ScopeMetrics()

    // Latest processed CIImage for Metal MTKView rendering
    private let frameLock = NSLock()
    private var _latestProcessedImage: CIImage?
    public var latestProcessedImage: CIImage? {
        frameLock.lock()
        defer { frameLock.unlock() }
        return _latestProcessedImage
    }

    // Active 3D LUT Cube Filter Data
    private var lutCubeData: Data?
    private var lutDimension: Int = 32
    private var frameCounter: Int = 0

    // Custom CIKernel for Zebra Stripes & Focus Peaking Overlay
    private let zebraAndPeakingKernel: CIColorKernel? = {
        let source = """
        kernel vec4 cinemaAssistOverlay(__sample src, __sample edge, float enableZebra, float zebraThreshold, float enablePeaking, float peakingThreshold, float phase) {
            float luma = dot(src.rgb, vec3(0.2126, 0.7152, 0.0722));
            vec3 outColor = src.rgb;

            // Diagonal Zebra Stripes on overexposed highlights
            if (enableZebra > 0.5 && luma >= zebraThreshold) {
                float coordSum = destCoord().x + destCoord().y + phase;
                float stripe = mod(floor(coordSum / 6.0), 2.0);
                outColor = mix(outColor, vec3(1.0, 0.15, 0.15), stripe * 0.75);
            }

            // Focus Peaking highlight on sharp high-frequency edges
            if (enablePeaking > 0.5) {
                float edgeStrength = max(edge.r, max(edge.g, edge.b));
                if (edgeStrength > peakingThreshold) {
                    outColor = mix(outColor, vec3(0.0, 1.0, 0.35), 0.85);
                }
            }

            return vec4(outColor, src.a);
        }
        """
        return CIColorKernel(source: source)
    }()

    public init() {
        let dev = MTLCreateSystemDefaultDevice()
        self.metalDevice = dev
        self.commandQueue = dev?.makeCommandQueue()
        let colorSpace = CGColorSpace(name: CGColorSpace.extendedLinearDisplayP3) ?? CGColorSpaceCreateDeviceRGB()
        if let dev {
            self.ciContext = CIContext(mtlDevice: dev, options: [
                .workingColorSpace: colorSpace,
                .cacheIntermediates: false
            ])
        } else {
            self.ciContext = CIContext()
        }
        buildDefaultHLGToRec709LUT()
    }

    // MARK: - Built-in 32x32x32 3D LUT Generator (10-Bit HLG/Log to Rec.709 Cinema Roll-off)
    public func buildDefaultHLGToRec709LUT() {
        let size = 32
        var cubeFloats = [Float](repeating: 0, count: size * size * size * 4)
        var offset = 0

        for z in 0..<size {
            let b = Float(z) / Float(size - 1)
            for y in 0..<size {
                let g = Float(y) / Float(size - 1)
                for x in 0..<size {
                    let r = Float(x) / Float(size - 1)

                    // Film-style S-curve & highlight shoulder compression for 10-bit HLG preview
                    let mappedR = Self.cinemaScurve(r) * 1.02
                    let mappedG = Self.cinemaScurve(g) * 0.99
                    let mappedB = Self.cinemaScurve(b) * 0.96

                    cubeFloats[offset + 0] = min(1.0, max(0.0, mappedR))
                    cubeFloats[offset + 1] = min(1.0, max(0.0, mappedG))
                    cubeFloats[offset + 2] = min(1.0, max(0.0, mappedB))
                    cubeFloats[offset + 3] = 1.0
                    offset += 4
                }
            }
        }

        self.lutDimension = size
        self.lutCubeData = Data(bytes: cubeFloats, count: cubeFloats.count * MemoryLayout<Float>.size)
    }

    private static func cinemaScurve(_ v: Float) -> Float {
        let clamped = max(0.0, min(1.0, v))
        return clamped * clamped * (3.0 - 2.0 * clamped)
    }

    // MARK: - Parse Custom .cube 3D LUT File
    public func loadCubeLUT(from url: URL) throws {
        let content = try String(contentsOf: url, encoding: .utf8)
        var size = 0
        var rgbValues: [Float] = []

        for rawLine in content.components(separatedBy: .newlines) {
            let line = rawLine.trimmingCharacters(in: .whitespacesAndNewlines)
            if line.isEmpty || line.hasPrefix("#") || line.hasPrefix("TITLE") || line.hasPrefix("DOMAIN_") {
                continue
            }
            if line.hasPrefix("LUT_3D_SIZE") {
                let parts = line.split(separator: " ")
                if parts.count >= 2, let parsedSize = Int(parts[1]) {
                    size = parsedSize
                }
                continue
            }
            let nums = line.split(whereSeparator: { $0 == " " || $0 == "\t" }).compactMap { Float($0) }
            if nums.count >= 3 {
                rgbValues.append(nums[0])
                rgbValues.append(nums[1])
                rgbValues.append(nums[2])
                rgbValues.append(1.0)
            }
        }

        guard size >= 2, rgbValues.count == size * size * size * 4 else {
            throw NSError(domain: "CubeLUTLoader", code: -2, userInfo: [
                NSLocalizedDescriptionKey: "Invalid .cube 3D LUT dimensions or entry count"
            ])
        }

        frameLock.lock()
        self.lutDimension = size
        self.lutCubeData = Data(bytes: rgbValues, count: rgbValues.count * MemoryLayout<Float>.size)
        frameLock.unlock()

        DispatchQueue.main.async {
            self.config.activeLUTName = url.deletingPathExtension().lastPathComponent
            self.config.isLUTPreviewEnabled = true
        }
    }

    // MARK: - Process Video Frame (Preview + LUT + Zebras + Peaking + Scopes)
    public func processVideoSampleBuffer(_ sampleBuffer: CMSampleBuffer) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        frameCounter += 1

        var workingImage = CIImage(cvPixelBuffer: pixelBuffer)
        let currentConfig = config

        // 1. Apply 3D LUT (Monitoring-only non-destructive preview)
        if currentConfig.isLUTPreviewEnabled, let cubeData = lutCubeData {
            if let colorCube = CIFilter(name: "CIColorCubeWithColorSpace") {
                colorCube.setValue(workingImage, forKey: kCIInputImageKey)
                colorCube.setValue(lutDimension, forKey: "inputCubeDimension")
                colorCube.setValue(cubeData, forKey: "inputCubeData")
                colorCube.setValue(CGColorSpace(name: CGColorSpace.displayP3) ?? CGColorSpaceCreateDeviceRGB(), forKey: "inputColorSpace")
                if let lutOut = colorCube.outputImage {
                    workingImage = lutOut
                }
            }
        }

        // 2. Apply Zebra Stripes & Focus Peaking Shader Overlay
        if (currentConfig.isZebraEnabled || currentConfig.isFocusPeakingEnabled),
           let kernel = zebraAndPeakingKernel {
            let edgeImage: CIImage
            if currentConfig.isFocusPeakingEnabled,
               let edgesFilter = CIFilter(name: "CIEdges", parameters: [
                   kCIInputImageKey: workingImage,
                   kCIInputIntensityKey: 3.5
               ]),
               let edgesOut = edgesFilter.outputImage?.cropped(to: workingImage.extent) {
                edgeImage = edgesOut
            } else {
                edgeImage = workingImage
            }

            let animatedPhase = Float((frameCounter * 2) % 24)
            if let assisted = kernel.apply(
                extent: workingImage.extent,
                arguments: [
                    workingImage,
                    edgeImage,
                    currentConfig.isZebraEnabled ? 1.0 : 0.0,
                    currentConfig.zebraThreshold,
                    currentConfig.isFocusPeakingEnabled ? 1.0 : 0.0,
                    currentConfig.focusPeakingThreshold,
                    animatedPhase
                ]
            ) {
                workingImage = assisted
            }
        }

        frameLock.lock()
        _latestProcessedImage = workingImage
        frameLock.unlock()

        // 3. Compute Real-Time RGB Histogram & Luma Waveform every 3rd frame
        if frameCounter % 3 == 0 && (currentConfig.showHistogram || currentConfig.showWaveform) {
            computeScopes(from: workingImage)
        }
    }

    // MARK: - Fast Downsampled RGB Histogram & Luma Waveform Computation
    private func computeScopes(from image: CIImage) {
        let sampleWidth = 48
        let sampleHeight = 27
        let extent = image.extent
        guard extent.width > 0 && extent.height > 0 else { return }

        let scaleX = CGFloat(sampleWidth) / extent.width
        let scaleY = CGFloat(sampleHeight) / extent.height
        let scaled = image.transformed(by: CGAffineTransform(scaleX: scaleX, y: scaleY))

        var rgbaBytes = [UInt8](repeating: 0, count: sampleWidth * sampleHeight * 4)
        ciContext.render(
            scaled,
            toBitmap: &rgbaBytes,
            rowBytes: sampleWidth * 4,
            bounds: CGRect(x: 0, y: 0, width: sampleWidth, height: sampleHeight),
            format: .RGBA8,
            colorSpace: CGColorSpaceCreateDeviceRGB()
        )

        var rBins = [Float](repeating: 0, count: 64)
        var gBins = [Float](repeating: 0, count: 64)
        var bBins = [Float](repeating: 0, count: 64)
        var waveform = [(min: Float, avg: Float, max: Float)](repeating: (1.0, 0.0, 0.0), count: sampleWidth)

        for x in 0..<sampleWidth {
            var colMin: Float = 1.0
            var colMax: Float = 0.0
            var colSum: Float = 0.0

            for y in 0..<sampleHeight {
                let idx = (y * sampleWidth + x) * 4
                let r = Float(rgbaBytes[idx + 0]) / 255.0
                let g = Float(rgbaBytes[idx + 1]) / 255.0
                let b = Float(rgbaBytes[idx + 2]) / 255.0

                rBins[min(63, Int(r * 63.0))] += 1
                gBins[min(63, Int(g * 63.0))] += 1
                bBins[min(63, Int(b * 63.0))] += 1

                let luma = 0.2126 * r + 0.7152 * g + 0.0722 * b
                colMin = min(colMin, luma)
                colMax = max(colMax, luma)
                colSum += luma
            }
            waveform[x] = (min: colMin, avg: colSum / Float(sampleHeight), max: colMax)
        }

        let maxCount = max(1.0, max(rBins.max() ?? 1, max(gBins.max() ?? 1, bBins.max() ?? 1)))
        let normR = rBins.map { $0 / maxCount }
        let normG = gBins.map { $0 / maxCount }
        let normB = bBins.map { $0 / maxCount }

        DispatchQueue.main.async {
            self.scopeMetrics.redHistogram = normR
            self.scopeMetrics.greenHistogram = normG
            self.scopeMetrics.blueHistogram = normB
            self.scopeMetrics.waveformColumns = waveform
        }
    }

    // MARK: - Stereo Audio Peak / RMS dBFS Analyzer
    public func processAudioSampleBuffer(_ sampleBuffer: CMSampleBuffer) {
        guard let blockBuffer = CMSampleBufferGetDataBuffer(sampleBuffer) else { return }
        var length = 0
        var dataPointer: UnsafeMutablePointer<Int8>?
        let status = CMBlockBufferGetDataPointer(
            blockBuffer,
            atOffset: 0,
            lengthAtOffsetOut: nil,
            totalLengthOut: &length,
            dataPointerOut: &dataPointer
        )
        guard status == kCMBlockBufferNoErr, let ptr = dataPointer, length >= 4 else { return }

        let sampleCount = length / MemoryLayout<Int16>.size
        ptr.withMemoryRebound(to: Int16.self, capacity: sampleCount) { int16Ptr in
            var leftPeak: Float = 0.00001
            var rightPeak: Float = 0.00001
            let step = max(2, (sampleCount / 256) * 2)

            var i = 0
            while i + 1 < sampleCount {
                let l = abs(Float(int16Ptr[i])) / Float(Int16.max)
                let r = abs(Float(int16Ptr[i + 1])) / Float(Int16.max)
                if l > leftPeak { leftPeak = l }
                if r > rightPeak { rightPeak = r }
                i += step
            }

            let leftDB = max(-60.0, min(0.0, 20.0 * log10(leftPeak)))
            let rightDB = max(-60.0, min(0.0, 20.0 * log10(rightPeak)))
            let maxDB = max(leftDB, rightDB)

            DispatchQueue.main.async {
                self.scopeMetrics.leftAudioDBFS = leftDB
                self.scopeMetrics.rightAudioDBFS = rightDB
                self.scopeMetrics.peakAudioDBFS = maxDB
            }
        }
    }
}
