import Foundation
import AVFoundation
import CoreMedia
import CoreVideo
import CoreImage
import VideoToolbox
import Photos
import UIKit
import Combine

// MARK: - iPhone 13 Pro Max Lens Definition
public enum CinemaLens: String, CaseIterable, Identifiable {
    case ultraWide = "13mm"
    case wide      = "26mm"
    case telephoto = "77mm"

    public var id: String { rawValue }

    public var displayName: String {
        switch self {
        case .ultraWide: return "13mm f/1.8 (0.5x)"
        case .wide:      return "26mm f/1.5 (1x)"
        case .telephoto: return "77mm f/2.8 (3x)"
        }
    }

    public var deviceType: AVCaptureDevice.DeviceType {
        switch self {
        case .ultraWide: return .builtInUltraWideCamera
        case .wide:      return .builtInWideAngleCamera
        case .telephoto: return .builtInTelephotoCamera
        }
    }
}

// MARK: - ProRes & 10-Bit Video Codec Options
public enum CinemaCodec: String, CaseIterable, Identifiable {
    case proRes422HQ    = "ProRes 422 HQ"
    case proRes422      = "ProRes 422"
    case proRes422LT    = "ProRes 422 LT"
    case proRes422Proxy = "ProRes 422 Proxy"
    case hevc10Bit      = "HEVC 10-Bit HLG"

    public var id: String { rawValue }

    public var avCodecType: AVVideoCodecType {
        switch self {
        case .proRes422HQ:    return .proRes422HQ
        case .proRes422:      return .proRes422
        case .proRes422LT:    return .proRes422LT
        case .proRes422Proxy: return .proRes422Proxy
        case .hevc10Bit:      return .hevc
        }
    }

    /// Approximate data rate in MB/s at 4K 30fps on iPhone 13 Pro Max
    public var approxDataRateMBpsAt4K30: Double {
        switch self {
        case .proRes422HQ:    return 92.0
        case .proRes422:      return 61.0
        case .proRes422LT:    return 42.5
        case .proRes422Proxy: return 19.0
        case .hevc10Bit:      return 12.5
        }
    }
}

// MARK: - Resolution & Frame Rate Presets
public enum CinemaResolution: String, CaseIterable, Identifiable {
    case uhd4K   = "4K (3840×2160)"
    case fhd1080 = "1080p (1920×1080)"

    public var id: String { rawValue }

    public var dimensions: CMVideoDimensions {
        switch self {
        case .uhd4K:   return CMVideoDimensions(width: 3840, height: 2160)
        case .fhd1080: return CMVideoDimensions(width: 1920, height: 1080)
        }
    }
}

public enum CinemaFrameRate: Int, CaseIterable, Identifiable {
    case fps24 = 24
    case fps25 = 25
    case fps30 = 30
    case fps60 = 60

    public var id: Int { rawValue }
}

// MARK: - Color Space / Dynamic Range Pipeline
public enum CinemaColorPipeline: String, CaseIterable, Identifiable {
    case hlgBT2020 = "10-Bit BT.2020 HLG"
    case p3D65     = "10-Bit P3-D65"
    case rec709    = "Rec.709 Standard"

    public var id: String { rawValue }
}

// MARK: - CameraEngine: Full Manual + 10-Bit ProRes Pipeline
public final class CameraEngine: NSObject, ObservableObject {
    // Session & Dedicated Serial Queues
    public let session = AVCaptureSession()
    private let sessionQueue = DispatchQueue(label: "com.cinema.prores.sessionQueue", qos: .userInteractive)
    private let videoOutputQueue = DispatchQueue(label: "com.cinema.prores.videoOutputQueue", qos: .userInteractive)
    private let audioOutputQueue = DispatchQueue(label: "com.cinema.prores.audioOutputQueue", qos: .userInteractive)
    private let writerQueue = DispatchQueue(label: "com.cinema.prores.writerQueue", qos: .utility)

    // Inputs & Outputs
    private var currentVideoDevice: AVCaptureDevice?
    private var videoDeviceInput: AVCaptureDeviceInput?
    private let videoDataOutput = AVCaptureVideoDataOutput()
    private let audioDataOutput = AVCaptureAudioDataOutput()

    // Real-Time Video Processor & Monitoring
    public let videoProcessor = VideoProcessor()

    // Published Camera State
    @Published public var isSessionRunning = false
    @Published public var selectedLens: CinemaLens = .wide
    @Published public var selectedCodec: CinemaCodec = .proRes422HQ
    @Published public var selectedResolution: CinemaResolution = .uhd4K
    @Published public var selectedFrameRate: CinemaFrameRate = .fps24
    @Published public var selectedColorPipeline: CinemaColorPipeline = .hlgBT2020

    // Manual Exposure, White Balance & Focus State
    @Published public var isManualExposure: Bool = true
    @Published public var currentISO: Float = 100.0
    @Published public var minISO: Float = 32.0
    @Published public var maxISO: Float = 3200.0

    /// Shutter angle in degrees (e.g., 180° = 1/(2*fps) sec)
    @Published public var shutterAngle: Double = 180.0
    @Published public var currentShutterSeconds: Double = 1.0 / 48.0

    @Published public var isManualWhiteBalance: Bool = true
    @Published public var whiteBalanceKelvin: Float = 5600.0
    @Published public var whiteBalanceTint: Float = 0.0

    @Published public var isManualFocus: Bool = false
    @Published public var lensPosition: Float = 0.5

    // Recording & System Telemetry State
    @Published public var isRecording: Bool = false
    @Published public var recordedDurationSeconds: Double = 0.0
    @Published public var timecodeString: String = "00:00:00:00"
    @Published public var availableStorageGB: Double = 0.0
    @Published public var estimatedRemainingMinutes: Int = 0
    @Published public var thermalStateDescription: String = "Nominal"
    @Published public var batteryLevelPercent: Int = 100
    @Published public var statusBannerMessage: String = "10-Bit ProRes Pipeline Ready"
    @Published public var isProRes4KSupportedOnDevice: Bool = true
    @Published public var lastSavedClipURL: URL?

    // AVAssetWriter State (Accessed on writerQueue)
    private var assetWriter: AVAssetWriter?
    private var videoWriterInput: AVAssetWriterInput?
    private var audioWriterInput: AVAssetWriterInput?
    private var isWriterSessionStarted: Bool = false
    private var recordingStartPTS: CMTime = .invalid
    private var activeRecordingURL: URL?
    private var telemetryTimer: Timer?

    public override init() {
        super.init()
        DispatchQueue.main.async {
            UIDevice.current.isBatteryMonitoringEnabled = true
        }
        checkDeviceProRes4KEligibility()
        updateSystemTelemetry()
        startTelemetryTimer()
    }

    // MARK: - iPhone 13 Pro Max Hardware Capability Verification
    private func checkDeviceProRes4KEligibility() {
        // iPhone 13 Pro / Pro Max requires >=256GB total capacity for 4K 30fps ProRes; 128GB models cap ProRes at 1080p 30fps
        if let attrs = try? FileManager.default.attributesOfFileSystem(forPath: NSHomeDirectory()),
           let totalBytes = attrs[.systemSize] as? Int64 {
            let totalGB = Double(totalBytes) / 1_000_000_000.0
            let eligible = totalGB > 140.0
            DispatchQueue.main.async {
                self.isProRes4KSupportedOnDevice = eligible
                if !eligible {
                    self.statusBannerMessage = "128GB Tier Detected: ProRes capped at 1080p 30fps"
                }
            }
        }
    }

    // MARK: - Permissions & Setup
    public func requestPermissionsAndSetup() {
        AVCaptureDevice.requestAccess(for: .video) { [weak self] videoGranted in
            guard let self else { return }
            guard videoGranted else {
                DispatchQueue.main.async {
                    self.statusBannerMessage = "Camera permission denied in Settings"
                }
                return
            }
            AVCaptureDevice.requestAccess(for: .audio) { [weak self] audioGranted in
                guard let self else { return }
                let lens = self.selectedLens
                self.sessionQueue.async {
                    self.configureSession(lens: lens, includeAudio: audioGranted)
                }
            }
        }
    }

    // MARK: - Session Configuration (Session Queue)
    private func configureSession(lens: CinemaLens, includeAudio: Bool) {
        session.beginConfiguration()
        session.sessionPreset = .inputPriority

        for input in session.inputs { session.removeInput(input) }
        for output in session.outputs { session.removeOutput(output) }

        // 1. Discover requested iPhone 13 Pro Max lens (with fallback to wide)
        let device = AVCaptureDevice.default(lens.deviceType, for: .video, position: .back)
            ?? AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back)

        guard let videoDevice = device,
              let vInput = try? AVCaptureDeviceInput(device: videoDevice),
              session.canAddInput(vInput) else {
            session.commitConfiguration()
            DispatchQueue.main.async {
                self.statusBannerMessage = "Unable to initialize camera sensor (\(lens.rawValue))"
            }
            return
        }
        session.addInput(vInput)
        currentVideoDevice = videoDevice
        videoDeviceInput = vInput

        // 2. Audio Input (48kHz stereo capture when available)
        if includeAudio,
           let audioDevice = AVCaptureDevice.default(for: .audio),
           let aInput = try? AVCaptureDeviceInput(device: audioDevice),
           session.canAddInput(aInput) {
            session.addInput(aInput)
        }

        // 3. Video Data Output (10-bit Bi-Planar YCbCr preferred for ProRes & HDR scopes)
        videoDataOutput.alwaysDiscardsLateVideoFrames = false
        let availablePixelFormats = videoDataOutput.availableVideoPixelFormatTypes
        let preferredPixelFormat: OSType
        if availablePixelFormats.contains(kCVPixelFormatType_422YpCbCr10BiPlanarVideoRange) {
            preferredPixelFormat = kCVPixelFormatType_422YpCbCr10BiPlanarVideoRange
        } else if availablePixelFormats.contains(kCVPixelFormatType_420YpCbCr10BiPlanarVideoRange) {
            preferredPixelFormat = kCVPixelFormatType_420YpCbCr10BiPlanarVideoRange
        } else {
            preferredPixelFormat = kCVPixelFormatType_32BGRA
        }
        videoDataOutput.videoSettings = [
            kCVPixelBufferPixelFormatTypeKey as String: Int(preferredPixelFormat)
        ]
        videoDataOutput.setSampleBufferDelegate(self, queue: videoOutputQueue)
        if session.canAddOutput(videoDataOutput) {
            session.addOutput(videoDataOutput)
        }

        if let connection = videoDataOutput.connection(with: .video) {
            if connection.isVideoOrientationSupported {
                connection.videoOrientation = .landscapeRight
            }
            if connection.isVideoStabilizationSupported {
                connection.preferredVideoStabilizationMode = .cinematicExtended
            }
        }

        // 4. Audio Data Output
        audioDataOutput.setSampleBufferDelegate(self, queue: audioOutputQueue)
        if session.canAddOutput(audioDataOutput) {
            session.addOutput(audioDataOutput)
        }

        session.commitConfiguration()

        if !session.isRunning {
            session.startRunning()
        }

        let running = session.isRunning
        DispatchQueue.main.async {
            self.isSessionRunning = running
            self.applyActiveFormatAndColorPipeline()
        }
    }

    // MARK: - Switch Lens (13mm / 26mm / 77mm)
    public func switchLens(to lens: CinemaLens) {
        guard !isRecording else {
            statusBannerMessage = "Cannot switch physical lens while recording ProRes"
            return
        }
        selectedLens = lens
        sessionQueue.async { [weak self] in
            guard let self else { return }
            self.configureSession(lens: lens, includeAudio: true)
        }
    }

    // MARK: - Select Best 10-Bit / ProRes Sensor Format
    public func applyActiveFormatAndColorPipeline() {
        // Enforce ProRes frame rate & resolution constraints on iPhone 13 Pro Max
        if selectedCodec != .hevc10Bit {
            if selectedFrameRate == .fps60 && selectedResolution == .uhd4K {
                selectedFrameRate = .fps30
                statusBannerMessage = "4K ProRes max frame rate is 30fps on iPhone 13 Pro Max"
            }
            if !isProRes4KSupportedOnDevice && selectedResolution == .uhd4K {
                selectedResolution = .fhd1080
            }
        }

        let targetDims = selectedResolution.dimensions
        let targetFPS = Double(selectedFrameRate.rawValue)
        let colorPipeline = selectedColorPipeline
        let lensName = selectedLens.rawValue
        let resName = selectedResolution.rawValue
        let codecName = selectedCodec.rawValue

        sessionQueue.async { [weak self] in
            guard let self, let device = self.currentVideoDevice else { return }
            do {
                try device.lockForConfiguration()
                defer { device.unlockForConfiguration() }

                // Filter formats matching target dimensions and frame rate, prioritizing 10-bit x420 / x422 and HLG_BT2020
                let matchingFormats = device.formats.filter { format in
                    let dims = CMVideoFormatDescriptionGetDimensions(format.formatDescription)
                    guard dims.width == targetDims.width && dims.height == targetDims.height else { return false }
                    return format.videoSupportedFrameRateRanges.contains { range in
                        range.minFrameRate <= targetFPS && targetFPS <= range.maxFrameRate
                    }
                }

                let chosenFormat = matchingFormats.max { a, b in
                    let subA = CMFormatDescriptionGetMediaSubType(a.formatDescription)
                    let subB = CMFormatDescriptionGetMediaSubType(b.formatDescription)
                    let is10BitA = (subA == kCVPixelFormatType_420YpCbCr10BiPlanarVideoRange || subA == kCVPixelFormatType_422YpCbCr10BiPlanarVideoRange)
                    let is10BitB = (subB == kCVPixelFormatType_420YpCbCr10BiPlanarVideoRange || subB == kCVPixelFormatType_422YpCbCr10BiPlanarVideoRange)
                    if is10BitA != is10BitB { return !is10BitA }
                    return a.supportedColorSpaces.count < b.supportedColorSpaces.count
                }

                if let bestFormat = chosenFormat {
                    device.activeFormat = bestFormat

                    switch colorPipeline {
                    case .hlgBT2020:
                        if bestFormat.supportedColorSpaces.contains(.HLG_BT2020) {
                            device.activeColorSpace = .HLG_BT2020
                        }
                    case .p3D65:
                        if bestFormat.supportedColorSpaces.contains(.P3_D65) {
                            device.activeColorSpace = .P3_D65
                        }
                    case .rec709:
                        if bestFormat.supportedColorSpaces.contains(.sRGB) {
                            device.activeColorSpace = .sRGB
                        }
                    }

                    let frameDuration = CMTimeMake(value: 1, timescale: Int32(targetFPS))
                    device.activeVideoMinFrameDuration = frameDuration
                    device.activeVideoMaxFrameDuration = frameDuration
                }

                let minISOVal = device.activeFormat.minISO
                let maxISOVal = device.activeFormat.maxISO
                let currentISOVal = max(minISOVal, min(maxISOVal, device.iso))

                DispatchQueue.main.async {
                    self.minISO = minISOVal
                    self.maxISO = maxISOVal
                    self.currentISO = currentISOVal
                    self.applyExposureSettings()
                    self.applyWhiteBalanceSettings()
                    self.statusBannerMessage = "\(lensName) • \(resName) @ \(Int(targetFPS))fps • \(codecName)"
                }
            } catch {
                DispatchQueue.main.async {
                    self.statusBannerMessage = "Format lock error: \(error.localizedDescription)"
                }
            }
        }
    }

    // MARK: - Manual ISO & Shutter Angle Control
    public func applyExposureSettings() {
        let manual = isManualExposure
        let requestedISO = currentISO
        let fps = Double(selectedFrameRate.rawValue)
        let angle = max(15.0, min(360.0, shutterAngle))
        let shutterSeconds = (angle / 360.0) / fps
        currentShutterSeconds = shutterSeconds

        sessionQueue.async { [weak self] in
            guard let self, let device = self.currentVideoDevice else { return }
            do {
                try device.lockForConfiguration()
                defer { device.unlockForConfiguration() }

                if manual && device.isExposureModeSupported(.custom) {
                    let clampedISO = max(device.activeFormat.minISO, min(device.activeFormat.maxISO, requestedISO))
                    let desiredDuration = CMTimeMakeWithSeconds(shutterSeconds, preferredTimescale: 1_000_000)
                    let minDur = device.activeFormat.minExposureDuration
                    let maxDur = device.activeFormat.maxExposureDuration
                    let clampedDuration = CMTimeClampToRange(desiredDuration, range: CMTimeRangeFromTimeToTime(start: minDur, end: maxDur))
                    device.setExposureModeCustom(duration: clampedDuration, iso: clampedISO, completionHandler: nil)
                } else if device.isExposureModeSupported(.continuousAutoExposure) {
                    device.exposureMode = .continuousAutoExposure
                }
            } catch {
                // Ignore transient lock contention
            }
        }
    }

    // MARK: - Manual White Balance (Kelvin + Tint) Control
    public func applyWhiteBalanceSettings() {
        let manual = isManualWhiteBalance
        let kelvin = whiteBalanceKelvin
        let tint = whiteBalanceTint

        sessionQueue.async { [weak self] in
            guard let self, let device = self.currentVideoDevice else { return }
            do {
                try device.lockForConfiguration()
                defer { device.unlockForConfiguration() }

                if manual && device.isWhiteBalanceModeSupported(.locked) {
                    let tempAndTint = AVCaptureDevice.WhiteBalanceTemperatureAndTintValues(
                        temperature: kelvin,
                        tint: tint
                    )
                    var gains = device.deviceWhiteBalanceGains(for: tempAndTint)
                    let maxGain = device.maxWhiteBalanceGain
                    gains.redGain   = max(1.0, min(maxGain, gains.redGain))
                    gains.greenGain = max(1.0, min(maxGain, gains.greenGain))
                    gains.blueGain  = max(1.0, min(maxGain, gains.blueGain))
                    device.setWhiteBalanceModeLocked(with: gains, completionHandler: nil)
                } else if device.isWhiteBalanceModeSupported(.continuousAutoWhiteBalance) {
                    device.whiteBalanceMode = .continuousAutoWhiteBalance
                }
            } catch {
                // Ignore transient lock contention
            }
        }
    }

    // MARK: - Manual Focus & Macro Pull Focus Control
    public func applyFocusSettings() {
        let manual = isManualFocus
        let pos = max(0.0, min(1.0, lensPosition))

        sessionQueue.async { [weak self] in
            guard let self, let device = self.currentVideoDevice else { return }
            do {
                try device.lockForConfiguration()
                defer { device.unlockForConfiguration() }

                if manual && device.isFocusModeSupported(.locked) {
                    device.setFocusModeLocked(lensPosition: pos, completionHandler: nil)
                } else if device.isFocusModeSupported(.continuousAutoFocus) {
                    device.focusMode = .continuousAutoFocus
                }
            } catch {
                // Ignore transient lock contention
            }
        }
    }

    // MARK: - ProRes & 10-Bit Recording Control
    public func toggleRecording() {
        if isRecording {
            stopRecording()
        } else {
            startRecording()
        }
    }

    public func startRecording() {
        guard !isRecording else { return }

        let dims = selectedResolution.dimensions
        let codec = selectedCodec
        let colorPipeline = selectedColorPipeline
        let lensTag = selectedLens.rawValue

        let docsDir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyyMMdd_HHmmss"
        let filename = "PRORES_\(lensTag)_\(formatter.string(from: Date())).mov"
        let outputURL = docsDir.appendingPathComponent(filename)

        writerQueue.async { [weak self] in
            guard let self else { return }
            do {
                if FileManager.default.fileExists(atPath: outputURL.path) {
                    try FileManager.default.removeItem(at: outputURL)
                }

                let writer = try AVAssetWriter(outputURL: outputURL, fileType: .mov)

                // Configure Video Output Settings for Apple ProRes or 10-Bit HEVC
                var videoSettings: [String: Any] = [
                    AVVideoCodecKey: codec.avCodecType,
                    AVVideoWidthKey: Int(dims.width),
                    AVVideoHeightKey: Int(dims.height)
                ]

                switch colorPipeline {
                case .hlgBT2020:
                    videoSettings[AVVideoColorPropertiesKey] = [
                        AVVideoColorPrimariesKey: AVVideoColorPrimaries_ITU_R_2020,
                        AVVideoTransferFunctionKey: AVVideoTransferFunction_ITU_R_2100_HLG,
                        AVVideoYCbCrMatrixKey: AVVideoYCbCrMatrix_ITU_R_2020
                    ]
                case .p3D65:
                    videoSettings[AVVideoColorPropertiesKey] = [
                        AVVideoColorPrimariesKey: AVVideoColorPrimaries_P3_D65,
                        AVVideoTransferFunctionKey: AVVideoTransferFunction_ITU_R_709_2,
                        AVVideoYCbCrMatrixKey: AVVideoYCbCrMatrix_ITU_R_709_2
                    ]
                case .rec709:
                    videoSettings[AVVideoColorPropertiesKey] = [
                        AVVideoColorPrimariesKey: AVVideoColorPrimaries_ITU_R_709_2,
                        AVVideoTransferFunctionKey: AVVideoTransferFunction_ITU_R_709_2,
                        AVVideoYCbCrMatrixKey: AVVideoYCbCrMatrix_ITU_R_709_2
                    ]
                }

                if codec == .hevc10Bit {
                    videoSettings[AVVideoCompressionPropertiesKey] = [
                        AVVideoAverageBitRateKey: 100_000_000,
                        AVVideoProfileLevelKey: kVTProfileLevel_HEVC_Main10_AutoLevel as String
                    ]
                }

                let vWriterInput = AVAssetWriterInput(mediaType: .video, outputSettings: videoSettings)
                vWriterInput.expectsMediaDataInRealTime = true
                if writer.canAdd(vWriterInput) {
                    writer.add(vWriterInput)
                }

                // Configure Uncompressed 48kHz 24-Bit Linear PCM Cinema Audio
                let audioSettings: [String: Any] = [
                    AVFormatIDKey: kAudioFormatLinearPCM,
                    AVSampleRateKey: 48000.0,
                    AVNumberOfChannelsKey: 2,
                    AVLinearPCMBitDepthKey: 24,
                    AVLinearPCMIsFloatKey: false,
                    AVLinearPCMIsBigEndianKey: false
                ]
                let aWriterInput = AVAssetWriterInput(mediaType: .audio, outputSettings: audioSettings)
                aWriterInput.expectsMediaDataInRealTime = true
                if writer.canAdd(aWriterInput) {
                    writer.add(aWriterInput)
                }

                guard writer.startWriting() else {
                    throw writer.error ?? NSError(domain: "ProResCinemaCam", code: -1, userInfo: [NSLocalizedDescriptionKey: "AVAssetWriter failed to start"])
                }

                self.assetWriter = writer
                self.videoWriterInput = vWriterInput
                self.audioWriterInput = aWriterInput
                self.isWriterSessionStarted = false
                self.recordingStartPTS = .invalid
                self.activeRecordingURL = outputURL

                DispatchQueue.main.async {
                    self.isRecording = true
                    self.recordedDurationSeconds = 0.0
                    self.statusBannerMessage = "REC • \(codec.rawValue) → \(filename)"
                }
            } catch {
                DispatchQueue.main.async {
                    self.statusBannerMessage = "Recording start error: \(error.localizedDescription)"
                }
            }
        }
    }

    public func stopRecording() {
        guard isRecording else { return }
        writerQueue.async { [weak self] in
            guard let self, let writer = self.assetWriter else { return }
            self.videoWriterInput?.markAsFinished()
            self.audioWriterInput?.markAsFinished()
            let outputURL = self.activeRecordingURL

            writer.finishWriting {
                self.assetWriter = nil
                self.videoWriterInput = nil
                self.audioWriterInput = nil
                self.isWriterSessionStarted = false

                if let clipURL = outputURL {
                    self.exportClipToPhotoLibrary(url: clipURL)
                }

                DispatchQueue.main.async {
                    self.isRecording = false
                    self.lastSavedClipURL = outputURL
                    self.updateSystemTelemetry()
                }
            }
        }
    }

    private func exportClipToPhotoLibrary(url: URL) {
        PHPhotoLibrary.requestAuthorization(for: .addOnly) { status in
            guard status == .authorized || status == .limited else { return }
            PHPhotoLibrary.shared().performChanges({
                PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: url)
            }) { success, error in
                DispatchQueue.main.async {
                    if success {
                        self.statusBannerMessage = "Saved ProRes Master (\(url.lastPathComponent)) to Photos & Files"
                    } else if let error {
                        self.statusBannerMessage = "Saved to Files app (\(error.localizedDescription))"
                    }
                }
            }
        }
    }

    // MARK: - Telemetry & Storage Estimation
    private func startTelemetryTimer() {
        DispatchQueue.main.async {
            self.telemetryTimer = Timer.scheduledTimer(withTimeInterval: 2.0, repeats: true) { [weak self] _ in
                self?.updateSystemTelemetry()
            }
        }
    }

    public func updateSystemTelemetry() {
        var freeGBVal = availableStorageGB
        if let attrs = try? FileManager.default.attributesOfFileSystem(forPath: NSHomeDirectory()),
           let freeBytes = attrs[.systemFreeSize] as? Int64 {
            freeGBVal = Double(freeBytes) / 1_000_000_000.0
        }

        let thermalText: String
        switch ProcessInfo.processInfo.thermalState {
        case .nominal:  thermalText = "Nominal"
        case .fair:     thermalText = "Warm"
        case .serious:  thermalText = "High Temp"
        case .critical: thermalText = "Critical"
        @unknown default: thermalText = "Nominal"
        }

        DispatchQueue.main.async {
            self.availableStorageGB = freeGBVal
            let mbPerSec = self.selectedCodec.approxDataRateMBpsAt4K30 * (self.selectedResolution == .uhd4K ? 1.0 : 0.25)
            let totalSeconds = (freeGBVal * 1000.0) / max(1.0, mbPerSec)
            self.estimatedRemainingMinutes = Int(totalSeconds / 60.0)

            let rawBattery = UIDevice.current.batteryLevel
            self.batteryLevelPercent = rawBattery >= 0 ? Int(rawBattery * 100) : 100
            self.thermalStateDescription = thermalText
        }
    }

    private func formatSMPTE(seconds: Double, fps: Int) -> String {
        guard seconds.isFinite && seconds >= 0 else { return "00:00:00:00" }
        let totalSeconds = Int(seconds)
        let hours = totalSeconds / 3600
        let minutes = (totalSeconds % 3600) / 60
        let secs = totalSeconds % 60
        let frames = Int((seconds - Double(totalSeconds)) * Double(max(1, fps)))
        return String(format: "%02d:%02d:%02d:%02d", hours, minutes, secs, frames)
    }
}

// MARK: - Video & Audio Sample Buffer Delegate
extension CameraEngine: AVCaptureVideoDataOutputSampleBufferDelegate, AVCaptureAudioDataOutputSampleBufferDelegate {
    public func captureOutput(
        _ output: AVCaptureOutput,
        didOutput sampleBuffer: CMSampleBuffer,
        from connection: AVCaptureConnection
    ) {
        if output === videoDataOutput {
            // 1. Process live video frame for Metal preview, 3D LUT, Zebras, Focus Peaking & Scopes
            videoProcessor.processVideoSampleBuffer(sampleBuffer)

            // 2. Append to ProRes AVAssetWriter if recording
            writerQueue.async { [weak self] in
                guard let self,
                      let writer = self.assetWriter,
                      writer.status == .writing,
                      let vInput = self.videoWriterInput else { return }

                let pts = CMSampleBufferGetPresentationTimeStamp(sampleBuffer)
                if !self.isWriterSessionStarted {
                    writer.startSession(atSourceTime: pts)
                    self.recordingStartPTS = pts
                    self.isWriterSessionStarted = true
                }

                if vInput.isReadyForMoreMediaData {
                    vInput.append(sampleBuffer)
                }

                let elapsed = CMTimeGetSeconds(CMTimeSubtract(pts, self.recordingStartPTS))
                DispatchQueue.main.async {
                    self.recordedDurationSeconds = max(0, elapsed)
                    self.timecodeString = self.formatSMPTE(seconds: elapsed, fps: self.selectedFrameRate.rawValue)
                }
            }
        } else if output === audioDataOutput {
            // 1. Analyze stereo audio peak/RMS dBFS for live VU meter
            videoProcessor.processAudioSampleBuffer(sampleBuffer)

            // 2. Append audio to ProRes AVAssetWriter if recording
            writerQueue.async { [weak self] in
                guard let self,
                      let writer = self.assetWriter,
                      writer.status == .writing,
                      self.isWriterSessionStarted,
                      let aInput = self.audioWriterInput,
                      aInput.isReadyForMoreMediaData else { return }
                aInput.append(sampleBuffer)
            }
        }
    }
}
